//
//  Watering+CoreDataProperties.swift
//  Evergreen
//
//  Created by Gabriel Narutowicz on 01/01/2014.
//
//

import Foundation
import CoreData


extension Watering {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Watering> {
        return NSFetchRequest<Watering>(entityName: "Watering")
    }

    @NSManaged public var amount: Int16
    @NSManaged public var date: Date?
    @NSManaged public var toPlant: Plant?

}

extension Watering : Identifiable {

}
