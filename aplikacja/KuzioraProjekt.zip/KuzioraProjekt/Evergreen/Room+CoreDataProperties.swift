//
//  Room+CoreDataProperties.swift
//  Evergreen
//
//  Created by Gabriel Narutowicz on 01/01/2014.
//
//

import Foundation
import CoreData


extension Room {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Room> {
        return NSFetchRequest<Room>(entityName: "Room")
    }

    @NSManaged public var name: String?
    @NSManaged public var side: String?
    @NSManaged public var toCategory: Category?
    @NSManaged public var toPlant: NSSet?

}

// MARK: Generated accessors for toPlant
extension Room {

    @objc(addToPlantObject:)
    @NSManaged public func addToToPlant(_ value: Plant)

    @objc(removeToPlantObject:)
    @NSManaged public func removeFromToPlant(_ value: Plant)

    @objc(addToPlant:)
    @NSManaged public func addToToPlant(_ values: NSSet)

    @objc(removeToPlant:)
    @NSManaged public func removeFromToPlant(_ values: NSSet)

}

extension Room : Identifiable {

}
