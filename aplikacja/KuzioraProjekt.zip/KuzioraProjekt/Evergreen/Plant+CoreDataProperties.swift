//
//  Plant+CoreDataProperties.swift
//  Evergreen
//
//  Created by Gabriel Narutowicz on 01/01/2014.
//
//

import Foundation
import CoreData


extension Plant {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Plant> {
        return NSFetchRequest<Plant>(entityName: "Plant")
    }

    @NSManaged public var desc: String?
    @NSManaged public var fertilizers: Bool
    @NSManaged public var name: String?
    @NSManaged public var sun: Int16
    @NSManaged public var water: Int16
    @NSManaged public var toRoom: Room?
    @NSManaged public var toWatering: NSSet?

}

// MARK: Generated accessors for toWatering
extension Plant {

    @objc(addToWateringObject:)
    @NSManaged public func addToToWatering(_ value: Watering)

    @objc(removeToWateringObject:)
    @NSManaged public func removeFromToWatering(_ value: Watering)

    @objc(addToWatering:)
    @NSManaged public func addToToWatering(_ values: NSSet)

    @objc(removeToWatering:)
    @NSManaged public func removeFromToWatering(_ values: NSSet)

}

extension Plant : Identifiable {

}
