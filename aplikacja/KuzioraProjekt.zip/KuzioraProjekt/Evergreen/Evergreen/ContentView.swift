//
//  ContentView.swift
//  Evergreen
//
//  Created by Gabriel Narutowicz on 01/01/2014.
//

import SwiftUI
import CoreData

struct ContentView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \Category.name, ascending: true)],
        animation: .default)
    private var categories: FetchedResults<Category>
    private func populateCategories() {
        for category in categoryList {
            let newCategory = Category(context: viewContext)
            newCategory.name = category.name
            newCategory.image = category.image
            do {
                try viewContext.save()
            } catch {
                let nsError = error as NSError
                fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
            }
        }
    }

    var body: some View {
        NavigationView {
            VStack(alignment: .leading) {
                Section(header: Text("Kategorie pomieszczen")) {
                    ScrollView(.horizontal) {
                        HStack{
                            ForEach(categories) { item in
                                NavigationLink(
                                    destination: RoomList(filter: item.name ?? ""),
                                    label: {
                                        HomeCard(name: item.name ?? "" , image: item.image ?? "")
                                    }
                                )
                                
                            }
                        }
                    }
                    .onAppear() {
                        if categories.count == 0 {
                            populateCategories()
                        }
                    }
                }
                .padding(.leading, 10)
                
                Divider()
                Section(header: Text("Dodaj nowe elementy")) {
                    NavigationLink (
                        destination: NewRoom(),
                        label: {
                            ZStack {
                                RoundedRectangle(cornerRadius: 20)
                                    .frame(width: .infinity, height: 50)
                                HStack {
                                    Text("Stworz nowy pokoj")
                                        .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                                        .foregroundColor(Color.white)
                                    Image(systemName: "plus.circle.fill")
                                        .accentColor(Color.white)
                                }
                            }
                        }
                    )
                    
                    NavigationLink (
                        destination: NewPlant(),
                        label: {
                            ZStack {
                                RoundedRectangle(cornerRadius: 20)
                                    .frame(width: .infinity, height: 50)
                                HStack {
                                    Text("Dodaj nowa rosline")
                                        .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                                        .foregroundColor(Color.white)
                                    Image(systemName: "leaf.fill")
                                        .accentColor(Color.white)
                                }
                                
                            }
                        }
                    )
                }
                .padding(.horizontal, 20)
                


                NavigationLink(destination: DumpWaterings(), label: {Text("Waterings dump")})


                Spacer()
                
                
                NavigationLink(
                    destination: PlantList(filter: "*"),
                    label: {
                        ZStack {
                            RoundedRectangle(cornerRadius: 20)
                                .fill(Color("CGreen"))
                                .frame(width: .infinity, height: 50)
                            HStack {
                                Text("Pokaz swoja kolekcje")
                                    .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                                    .foregroundColor(Color.white)
                                Image(systemName: "leaf.fill")
                                    .accentColor(Color.white)
                            }
                            
                        }
                    }
                ).padding(20)

            }
            .navigationBarTitle("Evergreen")
            
        }
    }

    /*private func addItem() {
        withAnimation {
            let newItem = Item(context: viewContext)
            newItem.timestamp = Date()

            do {
                try viewContext.save()
            } catch {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                let nsError = error as NSError
                fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
            }
        }
    }

    private func deleteItems(offsets: IndexSet) {
        withAnimation {
            offsets.map { items[$0] }.forEach(viewContext.delete)

            do {
                try viewContext.save()
            } catch {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                let nsError = error as NSError
                fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
            }
        }
    }*/
}

private let itemFormatter: DateFormatter = {
    let formatter = DateFormatter()
    formatter.dateStyle = .short
    formatter.timeStyle = .medium
    return formatter
}()

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}
