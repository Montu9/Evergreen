//
//  PlantList.swift
//  Evergreen
//
//  Created by Gabriel Narutowicz on 01/01/2014.
//

import SwiftUI

struct PlantList: View {
    @Environment(\.managedObjectContext) private var viewContext
    @FetchRequest var fetchRequest: FetchedResults<Plant>
    
    @State private var scaleFactor: CGFloat = 1.0
    
    init(filter: String) {
        _fetchRequest = FetchRequest<Plant>(
            sortDescriptors: [NSSortDescriptor(keyPath: \Plant.name, ascending: true)],
            predicate: NSPredicate(format: "toRoom.name LIKE %@", filter),
            animation: .default)
    }
    
    private func deletePlant(offsets: IndexSet) {
        withAnimation{
            for i in offsets {
                let p = fetchRequest[i]
                let pWaterings = p.toWatering as? Set<Watering> ?? []
                for pWater in pWaterings {
                    viewContext.delete(pWater)
                }
                viewContext.delete(p)
            }
            do {
                try viewContext.save()
            } catch {
                let nsError = error as NSError
                fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
            }
        }
    }
    
    var body: some View {
        VStack {
            List {
                ForEach(fetchRequest) { plant in
                    NavigationLink(
                        destination: PlantDetails(plantB: plant, filter: plant.name ?? ""),
                        label: {
                            HStack {
                                Image(systemName: "leaf")
                                Text("\(plant.name ?? "Roslina"), w pokoju: \(plant.toRoom?.name ?? "")")
                            }.font(.system(size: 16 * CGFloat(scaleFactor)))
                            
                            
                        })
                }.onDelete(perform: deletePlant)
            
            }.gesture(MagnificationGesture()
                .onChanged { value in
                    scaleFactor = value.magnitude
                }
            )
        }.navigationTitle("Kolekcja roslin")
    }
}

struct PlantList_Previews: PreviewProvider {
    static var previews: some View {
        PlantList(filter: "")
    }
}
