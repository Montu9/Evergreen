//
//  PlantDetails.swift
//  Evergreen
//
//  Created by Gabriel Narutowicz on 01/01/2014.
//

import SwiftUI

struct PlantDetails: View {
    @State private var plant: Plant
    @State var newDate: Date = Date()
    @State var waterAmount: Double = 0
    @State var sunToggle: Bool = false;
    @State var waterToggle: Bool = false;

    @State var errors: [String] = []
    
    
    @Environment(\.managedObjectContext) private var viewContext
    @FetchRequest var fetchRequest: FetchedResults<Watering>
    
    init(plantB: Plant, filter: String) {
        _plant = State(initialValue: plantB)
        _fetchRequest = FetchRequest<Watering>(
            sortDescriptors: [NSSortDescriptor(keyPath: \Watering.date, ascending: false)],
            predicate: NSPredicate(format: "toPlant.name = %@", filter),
            animation: .default)
        
    }
    
    
    func validateData() -> Bool {
        errors.removeAll()
        if  newDate == nil {
            errors.append("Bledna data")
        }
        if waterAmount < 0 || waterAmount > 10 {
            errors.append("Bledna wartosc wody")
        }
        
        if errors.count > 0 {
            return true
        } else {
            return false
        }
    }
    
    var body: some View {
        VStack(alignment: .leading) {
            ZStack {
                RoundedRectangle(cornerRadius: 20)
                    .fill(LinearGradient(
                            gradient: .init(colors: [Color("CGreen"), Color("CGreenDark")]),
                        startPoint: .init(x: 0.5, y: 1),
                        endPoint: .init(x: 0.5, y: 0)
                                            
                    ))
                    .frame(width: .infinity, height: 300)
            
                VStack(alignment: .leading) {
                    HStack {
                        Image(systemName: "leaf.fill")
                            .foregroundColor(Color.white)
                        Text(plant.name ?? "")
                            .fontWeight(.bold)
                            .font(.system(size: 35))
                            .foregroundColor(Color.white)
                    }
                    
                    Text(plant.desc ?? "")
                        .fontWeight(.semibold)
                        .font(.system(size: 25))
                        .padding(5)
                        .foregroundColor(Color.white)
                    Text("Roslina znajduje sie w: \(plant.toRoom?.name ?? "")")
                        .foregroundColor(Color.white)
                    if plant.fertilizers == true {
                        Text("\(plant.name ?? "") wymaga nawozenia")
                            .foregroundColor(Color.white)
                    } else {
                        Text("Nie nalezy nawozic \(plant.name ?? "")")
                            .foregroundColor(Color.white)
                    }
                    HStack {
                        if !waterToggle {
                            ForEach(1..<11) {i in
                                if i <= Int(plant.water) {
                                    Image(systemName: "drop.fill")
                                        .font(.system(size: 25))
                                        .foregroundColor(Color.blue)
                                } else {
                                    Image(systemName: "drop")
                                        .font(.system(size: 25))
                                        .foregroundColor(Color.blue)
                                }
                                
                            }
                        } else {
                            if Int(plant.water) < 4 {
                                Text("Delikatnie podlewaj rosline")
                            } else if Int(plant.water) < 4 {
                                Text("Umiarkowanie podlewaj rosline")
                            } else {
                                Text("Obficie podlewaj rosline")
                            }
                            
                        }
                        
                    }.foregroundColor(Color.white)
                    .padding(10)
                    .onTapGesture(count: 2) {
                        waterToggle = !waterToggle
                    }

                    HStack {
                        if !sunToggle {
                            ForEach(1..<11) {i in
                                if i <= Int(plant.sun) {
                                    Image(systemName: "sun.max.fill")
                                        .font(.system(size: 20))
                                        .foregroundColor(Color.orange)
                                } else {
                                    Image(systemName: "sun.max")
                                        .font(.system(size: 20))
                                        .foregroundColor(Color.orange)
                                }
                                
                            }
                        } else {
                            if Int(plant.sun) < 4 {
                                Text("Roslina lubi cien")
                            } else if Int(plant.sun) < 4 {
                                Text("Roslina lubi umiarkowane slonce")
                            } else {
                                Text("Roslina lubi slonce")
                            }
                            
                        }
                        
                    }.foregroundColor(Color.white)
                    .padding(10)
                    .onTapGesture(count: 2) {
                        sunToggle = !sunToggle
                    }
                    
                    
                }.padding(10)
            }.fixedSize(horizontal: false, vertical: true)
            .onAppear() {
                viewContext.refreshAllObjects()
            }
            
            NavigationLink(
                destination: EditPlant(plantB: plant),
               label: {
                HStack {
                    Text("Edytuj rosline")
                        .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                        .foregroundColor(Color("CGreen"))
                    Image(systemName: "leaf.fill")
                        .accentColor(Color("CGreen"))
                }.frame(width: .infinity, height: 60)
               })
            
            Form {
                Section(header: Text("Szczegoly podlewania")) {
                    DatePicker("Data podlewania", selection: $newDate, displayedComponents: [.date])
                        .datePickerStyle(CompactDatePickerStyle())
                    Slider(value: $waterAmount, in: 1...10, step: 1)
                    
                    Button(action: ({
                        if validateData() {
                            return
                        }
                        let newWatering = Watering(context: viewContext)
                        newWatering.amount = Int16(waterAmount)
                        newWatering.date = newDate
                        newWatering.toPlant = plant
                        do {
                            try viewContext.save()
                        } catch {
                            let nsError = error as NSError
                            fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
                        }
                    }), label: {
                        
                    })
                }
                
                
                if errors.count != 0 {
                    Section(header: Text("Wystapil blad!")) {
                        ForEach(errors, id: \.self) { error in
                            Text(error)
                                .fontWeight(.bold)
                                .foregroundColor(Color.red)
                                
                        }
                    }
                }
                Section(header: Text("Historia podlewania")) {
                    List {
                        ForEach(fetchRequest) { watering in
                            HStack {
                                Image(systemName: "drop.fill")
                                Text(watering.date ?? Date(), style: .date)
                                Text("ilosc: \(watering.amount ?? 0)")
                            }.gesture(LongPressGesture()
                                        .onEnded{ _ in
                                            viewContext.delete(watering)
                                            do {
                                                try viewContext.save()
                                            } catch {
                                                let nsError = error as NSError
                                                fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
                                            }
                                        })
                        }
                    }
                }
            }
            
            

        }
        .padding(20)
        .navigationTitle("Szczegoly")
        
        

    }
}

struct PlantDetails_Previews: PreviewProvider {
    static var previews: some View {
        PlantDetails(plantB: Plant(), filter: "")
    }
}
