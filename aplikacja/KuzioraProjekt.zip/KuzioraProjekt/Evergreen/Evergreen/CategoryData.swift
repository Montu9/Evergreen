//
//  CategoryData.swift
//  Evergreen
//
//  Created by Gabriel Narutowicz on 01/01/2014.
//

import SwiftUI

struct CategoryTemplate {
    var name: String
    var image: String
}

let categoryList: [CategoryTemplate] = [
    CategoryTemplate(name: "Salon", image: "salon"),
    CategoryTemplate(name: "Sypialnia", image: "sypialnia"),
    CategoryTemplate(name: "Kuchnia", image: "kuchnia"),
    CategoryTemplate(name: "Biuro", image: "biuro"),
    CategoryTemplate(name: "Lazienka", image: "lazienka"),
    CategoryTemplate(name: "Pokoj", image: "pokoj")
]
