//
//  HomeCard.swift
//  Evergreen
//
//  Created by Gabriel Narutowicz on 01/01/2014.
//

import SwiftUI

struct HomeCard: View {
    var name: String
    var image: String
    
    var body: some View {
        ZStack {
            Image(image)
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(width: 180, height: 250)
                .mask(
                    RoundedRectangle(cornerRadius: 20)
                        .frame(width: 180, height: 250)
                )

                ZStack(alignment: Alignment.leading) {
                    RoundedRectangle(cornerRadius: 20)
                        .fill(LinearGradient(
                                gradient: .init(colors: [Color.black, Color.black.opacity(0)]),
                            startPoint: .init(x: 0.5, y: 1),
                            endPoint: .init(x: 0.5, y: 0)
                                                
                        ))
                        .offset(y: -25)
                        .frame(width: 180, height: 100)
                        
                    HStack {
                        Text(name)
                            .fontWeight(.heavy)
                            .foregroundColor(Color.white)
                            .multilineTextAlignment(.leading)
                            .padding(15)
                        Image(systemName: "arrow.right.circle.fill")
                            .accentColor(Color.white)
                    }.frame(width: 180, height: 50)
                    
                }.offset(y:100)

            
            
        }
    }
}

struct HomeCard_Previews: PreviewProvider {
    static var previews: some View {
        HomeCard(name: "", image: "")
    }
}
