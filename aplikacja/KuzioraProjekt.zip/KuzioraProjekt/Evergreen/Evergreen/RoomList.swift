//
//  RoomList.swift
//  Evergreen
//
//  Created by Gabriel Narutowicz on 01/01/2014.
//

import SwiftUI

struct RoomList: View {
    @Environment(\.managedObjectContext) private var viewContext
    @FetchRequest var fetchRequest: FetchedResults<Room>
    
    init(filter: String) {
        _fetchRequest = FetchRequest<Room>(
            sortDescriptors: [NSSortDescriptor(keyPath: \Room.name, ascending: true)],
            predicate: NSPredicate(format: "toCategory.name = %@", filter),
            animation: .default)
    }
    
    private func deleteRoom(offsets: IndexSet) {
        withAnimation{
            for i in offsets {
                let r = fetchRequest[i]
                let rPlants = r.toPlant as? Set<Plant> ?? []
                if rPlants.count != 0 {
                    let alert = UIAlertController(title: "Blad usuwania!", message: "Nie mozna usunac pokoju poniewaz znajduja sie w nim rosliny", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Aha"), style: .default, handler: { _ in
                        NSLog("The laert occured")
                    }))
                    let viewController = UIApplication.shared.windows.first!.rootViewController!
                    viewController.present(alert, animated: true, completion: nil)
                    return
                } else {
                    viewContext.delete(r)
                }
                do {
                    try viewContext.save()
                } catch {
                    let nsError = error as NSError
                    fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
                }
            }
        }
    }
    
    var body: some View {
        VStack {
            List {
                ForEach(fetchRequest) { room in
                    NavigationLink(
                        destination: PlantList(filter: room.name ?? ""),
                        label: {
                            HStack {
                                Image(systemName: "doc.text.image")
                                Text("\(room.name ?? "Pokoj"), w strone: \(room.side ?? "")")
                            }
                        })
                    
                    
                }.onDelete(perform: deleteRoom)
            }
        }.navigationTitle("Kolekcja miejsc")
    }
}

struct RoomList_Previews: PreviewProvider {
    static var previews: some View {
        RoomList(filter: "")
    }
}
