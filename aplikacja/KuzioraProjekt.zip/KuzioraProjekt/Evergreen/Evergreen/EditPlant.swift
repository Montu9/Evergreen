//
//  EditPlant.swift
//  Evergreen
//
//  Created by Gabriel Narutowicz on 09/06/2023.
//

import SwiftUI

struct EditPlant: View {
    @Environment(\.managedObjectContext) private var viewContext
    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \Room.name, ascending: true)],
        animation: .default)
    private var rooms: FetchedResults<Room>

    @ObservedObject var plant: Plant
    @State private var newName: String = ""
    @State private var newDesc: String = ""
    @State private var selectedRoom: Room?
    @State private var fertilizers: Bool = false
    @State private var waterAmount: Double = 0
    @State private var sunAmount: Double = 0
    
    @State var errors: [String] = []
    
    @Environment(\.presentationMode) var presentationMode
    
    init(plantB: Plant) {
        _plant = ObservedObject(initialValue: plantB)
        _newName = State(initialValue: plantB.name ?? "")
        _newDesc = State(initialValue: plantB.desc ?? "")
        _selectedRoom = State(initialValue: plantB.toRoom)
        _fertilizers = State(initialValue: plantB.fertilizers)
        _waterAmount = State(initialValue: Double(plantB.water))
        _sunAmount = State(initialValue: Double(plantB.sun))
    }
    
    func validateData() -> Bool {
        errors.removeAll()
        if newName.count <= 3 {
            errors.append("Bledna nazwa")
        }
        if newDesc.count <= 5 {
            errors.append("Bledny opis")
        }
        if selectedRoom == nil {
            errors.append("Bledny pokoj")
        }
        if fertilizers != false && fertilizers != true {
            errors.append("Bledna opcja nawozenia")
        }
        if waterAmount < 0 || waterAmount > 10 {
            errors.append("Bledna wartosc wody")
        }
        if sunAmount < 0 || sunAmount > 10 {
            errors.append("Bledna wartosc slonca")
        }
        
        if errors.count > 0 {
            return true
        } else {
            return false
        }
    }
    
    var body: some View {
        VStack {
            Form {
                Section(header: Text("Szczegoly")) {
                    TextField("Nazwa", text: $newName)
                    TextField("Opis", text: $newDesc)
                    Picker("Pokoj", selection: $selectedRoom) {
                        ForEach(rooms) { room in
                            Text("\(room.name ?? ""), \(room.toCategory?.name ?? "")").tag(room as Room?)
                        }
                    }
                    Toggle(
                        isOn: $fertilizers,
                        label: {
                            Text("Nawozenie")
                    })
                }
                
                Section(header: Text("Woda")) {
                    Slider(value: $waterAmount, in: 1...10, step: 1)
                }
                
                Section(header: Text("Slonce")) {
                    Slider(value: $sunAmount, in: 1...10, step: 1)
                }
                Button(action: ({
                    if validateData() {
                        return
                    }
                    
                    plant.name = newName
                    plant.desc = newDesc
                    plant.fertilizers = fertilizers
                    plant.toRoom = selectedRoom
                    plant.water = Int16(waterAmount)
                    plant.sun = Int16(sunAmount)
                    do {
                        try viewContext.save()
                        self.presentationMode.wrappedValue.dismiss()
                    } catch {
                        let nsError = error as NSError
                        fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
                    }
                }), label: {
                    HStack {
                        Text("Edytuj roslinke")
                            .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                            .foregroundColor(Color("CGreen"))
                        Image(systemName: "plus.circle.fill")
                            .accentColor(Color("CGreen"))
                    }
                })
                
                if errors.count != 0 {
                    Section(header: Text("Wystapil blad!")) {
                        ForEach(errors, id: \.self) { error in
                            Text(error)
                                .fontWeight(.bold)
                                .foregroundColor(Color.red)
                                
                        }
                    }
                }
            }
            .accentColor(Color("CGreen"))
        }.navigationTitle("Edycja rosliny")
    }
}

struct EditPlant_Previews: PreviewProvider {
    static var previews: some View {
        EditPlant(plantB: Plant())
    }
}
