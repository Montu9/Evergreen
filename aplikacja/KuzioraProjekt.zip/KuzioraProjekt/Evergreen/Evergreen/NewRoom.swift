//
//  NewRoom.swift
//  Evergreen
//
//  Created by Gabriel Narutowicz on 01/01/2014.
//

import SwiftUI

enum Side: String, CaseIterable, Identifiable {
    case Polnoc, Poludnie, Wschod, Zachod
    var id: Self { self }
}

struct NewRoom: View {
    @State var newName: String = ""
    @State var selectedSide: Side = .Polnoc
    @State var selectedCategory: Category?
    @State var errors: [String] = []
    
    @Environment(\.presentationMode) var presentationMode
    
    @Environment(\.managedObjectContext) private var viewContext
    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \Category.name, ascending: true)],
        animation: .default)
    private var categories: FetchedResults<Category>
    
    func validateData() -> Bool {
        errors.removeAll()
        if newName.count <= 3 {
            errors.append("Bledna nazwa")
        }
        if selectedSide.rawValue == "" {
            errors.append("Bledny kierunek")
        }
        if selectedCategory == nil {
            errors.append("Bledna kategoria")
        }
        
        if errors.count > 0 {
            return true
        } else {
            return false
        }
    }
    
    var body: some View {
        VStack {
            
            Text("Grupuj swoje roslinki do woli! Wybierz kategorie swojego pomieszczenia, podaj jego nazwe i kierunek w ktorym skierowane sa okna. Zarzadzanie swoja kolekcja roslin nie bylo prostsze!")
                .font(.body)
            
            Form {
                Section(header: Text("Szczegoly")) {
                    TextField("Nazwa", text: $newName)
                    Picker("Kierunek okien", selection: $selectedSide) {
                        ForEach(Side.allCases) { side in
                            Text(side.rawValue.capitalized)
                        }
                    }
                    Picker("Kategoria", selection: $selectedCategory) {
                        ForEach(categories) { category in
                            Text(category.name!).tag(category as Category?)
                        }
                    }
                }
                Button(action: ({
                    if validateData() {
                       return
                    }
                    let newRoom = Room(context: viewContext)
                    newRoom.name = newName
                    newRoom.side = selectedSide.rawValue
                    newRoom.toCategory = selectedCategory
                    do {
                        try viewContext.save()
                        self.presentationMode.wrappedValue.dismiss()
                    } catch {
                        let nsError = error as NSError
                        fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
                    }
                }), label: {
                    HStack {
                        Text("Dodaj pomieszczenie")
                            .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                            .foregroundColor(Color("CGreen"))
                        Image(systemName: "plus.circle.fill")
                            .accentColor(Color("CGreen"))
                    }
                })
                
                if errors.count != 0 {
                    Section(header: Text("Wystapil blad!")) {
                        ForEach(errors, id: \.self) { error in
                            Text(error)
                                .fontWeight(.bold)
                                .foregroundColor(Color.red)
                                
                        }
                    }
                }
            }
            
            
            
            Spacer()
        }.navigationTitle("Dodaj pokoj")
        .padding()
    }
}

struct NewRoom_Previews: PreviewProvider {
    static var previews: some View {
        NewRoom()
    }
}
