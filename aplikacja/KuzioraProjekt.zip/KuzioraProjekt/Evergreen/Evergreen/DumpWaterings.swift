//
//  DumpWaterings.swift
//  Evergreen
//
//  Created by Gabriel Narutowicz on 09/06/2023.
//

import SwiftUI

struct DumpWaterings: View {
    @Environment(\.managedObjectContext) private var viewContext
    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \Watering.date, ascending: true)],
        animation: .default)
    private var waterings: FetchedResults<Watering>
    
    var body: some View {
        VStack {
            List {
                ForEach(waterings) { water in
                    HStack {
                        Image(systemName: "drop.fill")
                        Text(water.date ?? Date(), style: .date)
                        Text("ilosc: \(water.amount ?? 0)")
                    }
                }
            }
        }
        
    }
}

struct DumpWaterings_Previews: PreviewProvider {
    static var previews: some View {
        DumpWaterings()
    }
}
