//
//  EvergreenApp.swift
//  Evergreen
//
//  Created by Gabriel Narutowicz on 01/01/2014.
//

import SwiftUI

@main
struct EvergreenApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
