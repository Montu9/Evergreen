//
//  NewPlant.swift
//  Evergreen
//
//  Created by Gabriel Narutowicz on 01/01/2014.
//

import SwiftUI
import Foundation

struct NewPlant: View {
    @State private var newName: String = ""
    @State private var newDesc: String = ""
    @State private var selectedRoom: Room?
    @State private var fertilizers: Bool = false
    @State private var waterAmount: Double = 0
    @State private var sunAmount: Double = 0
    
    @State var errors: [String] = []
    
    @Environment(\.presentationMode) var presentationMode
    
    @Environment(\.managedObjectContext) private var viewContext
    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \Room.name, ascending: true)],
        animation: .default)
    private var rooms: FetchedResults<Room>
    
    func validateData() -> Bool {
        errors.removeAll()
        if newName.count <= 3 {
            errors.append("Bledna nazwa")
        }
        if newDesc.count <= 5 {
            errors.append("Bledny opis")
        }
        if selectedRoom == nil {
            errors.append("Bledny pokoj")
        }
        if fertilizers != false && fertilizers != true {
            errors.append("Bledna opcja nawozenia")
        }
        if waterAmount < 0 || waterAmount > 10 {
            errors.append("Bledna wartosc wody")
        }
        if sunAmount < 0 || sunAmount > 10 {
            errors.append("Bledna wartosc slonca")
        }
        
        if errors.count > 0 {
            return true
        } else {
            return false
        }
    }
    
    var body: some View {
        VStack {
            Form {
                Section(header: Text("Szczegoly")) {
                    TextField("Nazwa", text: $newName)
                    TextField("Opis", text: $newDesc)
                    Picker("Pokoj", selection: $selectedRoom) {
                        ForEach(rooms) { room in
                            Text("\(room.name ?? ""), \(room.toCategory?.name ?? "")").tag(room as Room?)
                        }
                    }
                    Toggle(
                        isOn: $fertilizers,
                        label: {
                            Text("Nawozenie")
                    })
                }
                
                Section(header: Text("Woda")) {
                    Slider(value: $waterAmount, in: 1...10, step: 1)
                }
                
                Section(header: Text("Slonce")) {
                    Slider(value: $sunAmount, in: 1...10, step: 1)
                }
                Button(action: ({
                    if validateData() {
                        return
                    }
                    
                    let newPlant = Plant(context: viewContext)
                    newPlant.name = newName
                    newPlant.desc = newDesc
                    newPlant.fertilizers = fertilizers
                    newPlant.toRoom = selectedRoom
                    newPlant.water = Int16(waterAmount)
                    newPlant.sun = Int16(sunAmount)
                    do {
                        try viewContext.save()
                        self.presentationMode.wrappedValue.dismiss()
                    } catch {
                        let nsError = error as NSError
                        fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
                    }
                }), label: {
                    HStack {
                        Text("Dodaj roslinke")
                            .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                            .foregroundColor(Color("CGreen"))
                        Image(systemName: "plus.circle.fill")
                            .accentColor(Color("CGreen"))
                    }
                })
                
                if errors.count != 0 {
                    Section(header: Text("Wystapil blad!")) {
                        ForEach(errors, id: \.self) { error in
                            Text(error)
                                .fontWeight(.bold)
                                .foregroundColor(Color.red)
                                
                        }
                    }
                }
            }
            .accentColor(Color("CGreen"))
            
            Spacer()
        }.navigationTitle("Dodaj rosline")
    }
}

struct NewPlant_Previews: PreviewProvider {
    static var previews: some View {
        NewPlant()
    }
}
