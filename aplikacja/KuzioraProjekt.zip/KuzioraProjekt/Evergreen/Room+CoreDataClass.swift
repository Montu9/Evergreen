//
//  Room+CoreDataClass.swift
//  Evergreen
//
//  Created by Gabriel Narutowicz on 01/01/2014.
//
//

import Foundation
import CoreData

@objc(Room)
public class Room: NSManagedObject {

}
